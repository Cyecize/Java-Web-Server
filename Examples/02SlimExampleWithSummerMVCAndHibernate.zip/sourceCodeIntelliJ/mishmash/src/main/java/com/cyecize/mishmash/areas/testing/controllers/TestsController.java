package com.cyecize.mishmash.areas.testing.controllers;

import com.cyecize.mishmash.areas.language.services.LocalLanguage;
import com.cyecize.mishmash.controllers.BaseController;
import com.cyecize.solet.SoletConfig;
import com.cyecize.solet.SoletConstants;
import com.cyecize.solet.SoletLogger;
import com.cyecize.summer.areas.security.annotations.PreAuthorize;
import com.cyecize.summer.areas.security.enums.AuthorizationType;
import com.cyecize.summer.common.annotations.Autowired;
import com.cyecize.summer.common.annotations.Configuration;
import com.cyecize.summer.common.annotations.Controller;
import com.cyecize.summer.common.annotations.routing.GetMapping;
import com.cyecize.summer.common.annotations.routing.RequestMapping;
import com.cyecize.summer.common.models.Model;
import com.cyecize.summer.common.models.ModelAndView;

@Controller
@RequestMapping("/test")
@PreAuthorize(AuthorizationType.LOGGED_IN)
public class TestsController extends BaseController {

    private final String testName;

    private final int testInt;

    private final double testDouble;

    private final char testChar;

    /**
     * You can also inject properties that are coming from {@link com.cyecize.javache.services.JavacheConfigService}
     */
    @Autowired
    @Configuration("RESOURCE_CACHING_EXPRESSION")
    private String cachingExpression;

    /**
     * You can also inject properties that are coming from {@link SoletConfig}
     */
    @Autowired
    @Configuration(SoletConstants.SOLET_CONFIG_ASSETS_DIR)
    private String assetsDir;

    private final SoletLogger soletLogger;

    @Autowired
    public TestsController(LocalLanguage localLanguage,
                           @Configuration("test.name") String testName,
                           @Configuration("test.integer") int testInt,
                           @Configuration("test.double") double testDouble,
                           @Configuration("test.char") char testChar,
                           @Configuration(SoletConstants.SOLET_CONFIG_LOGGER) SoletLogger soletLogger) {
        super(localLanguage);
        this.testName = testName;
        this.testInt = testInt;
        this.testDouble = testDouble;
        this.testChar = testChar;
        this.soletLogger = soletLogger;
    }

    @GetMapping("/config")
    public ModelAndView testConfigs(Model model) {

        model.addAttribute("testName", this.testName);
        model.addAttribute("testInteger", this.testInt);
        model.addAttribute("testDouble", this.testDouble);
        model.addAttribute("testChar", this.testChar);
        model.addAttribute("cachingExpression", this.cachingExpression);
        model.addAttribute("soletLogger", this.soletLogger);
        model.addAttribute("assetsDir", this.assetsDir);


        return super.view("tests/configs.twig");
    }
}
