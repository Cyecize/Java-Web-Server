package com.cyecize.bdz.servlets.user;

import com.cyecize.bdz.constants.WebConstants;
import com.cyecize.bdz.entities.User;
import com.cyecize.http.HttpStatus;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;
import com.google.gson.Gson;


@WebSolet("/logged-user/details")
public class UserDetailsSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        if (!request.getSession().getAttributes().containsKey(WebConstants.USERNAME_SESSION_ID)) {
            response.setStatusCode(HttpStatus.UNAUTHORIZED);
            response.setContent(" ".getBytes());
            response.addHeader("Location", "/");
            return;
        }
        response.addHeader("Content-Type", "application/json");
        var session = request.getSession().getAttributes();
        User user = new User(session.get(WebConstants.USERNAME_SESSION_ID).toString(), session.get("password").toString());
        response.setContent(new Gson().toJson(user).getBytes());
    }
}
