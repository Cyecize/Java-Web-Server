package com.cyecize.mishmash.areas.channels.bindingModels;

import com.cyecize.mishmash.areas.channels.bindingModels.validators.UniqueCategoryName;
import com.cyecize.summer.areas.validation.constraints.FieldMatch;
import com.cyecize.summer.areas.validation.constraints.MinLength;
import com.cyecize.summer.areas.validation.constraints.NotNull;

public class CategoryBindingModel {

    @NotNull(message = "fieldCannotBeEmpty")
    @MinLength(length = 3, message = "invalidValue")
    @UniqueCategoryName
    private String latinName;

    @NotNull(message = "fieldCannotBeEmpty")
    @MinLength(length = 3, message = "invalidValue")
    @UniqueCategoryName
    @FieldMatch(fieldToMatch = "latinName", inverted = true)
    private String cyrillicName;

    public CategoryBindingModel() {

    }

    public String getLatinName() {
        return latinName;
    }

    public void setLatinName(String latinName) {
        this.latinName = latinName;
    }

    public String getCyrillicName() {
        return cyrillicName;
    }

    public void setCyrillicName(String cyrillicName) {
        this.cyrillicName = cyrillicName;
    }

}
