package com.cyecize.mishmash.areas.language.services;


import com.cyecize.mishmash.areas.language.enums.LanguageLocaleType;
import com.cyecize.mishmash.areas.language.languagePacks.Dictionary;
import com.cyecize.mishmash.areas.language.languagePacks.ErrorDictionary;

public interface LocalLanguage {

    Dictionary dictionary();

    ErrorDictionary errors();

    LanguageLocaleType getLocaleType();

    String forName(String phraseName);

    String locale();

    void updateLanguage(LanguageLocaleType localeType);

}
