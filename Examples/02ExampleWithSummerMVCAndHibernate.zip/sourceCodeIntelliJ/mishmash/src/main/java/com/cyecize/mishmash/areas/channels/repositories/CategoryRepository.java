package com.cyecize.mishmash.areas.channels.repositories;

import com.cyecize.mishmash.areas.channels.entities.ChannelCategory;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;

@Service
public class CategoryRepository extends BaseRepository<ChannelCategory, Long> {

    public ChannelCategory findOneByName(String name) {
        return super.queryBuilderSingle((channelCategoryCriteriaQuery, channelCategoryRoot) -> channelCategoryCriteriaQuery.where(
                super.criteriaBuilder.or(
                        super.criteriaBuilder.equal(channelCategoryRoot.get("latinName"), name),
                        super.criteriaBuilder.equal(channelCategoryRoot.get("cyrillicName"), name)
                )
        ));
    }
}
