package com.cyecize.mishmash.areas.language.languagePacks;

public interface ErrorDictionary  {

    String usernameIsNull();

    String usernameInvalidFormat();

    String usernameTaken();

    String emailIsNull();

    String emailTaken();

    String passwordLengthIsLessThan();

    String passwordsDoNotMatch();

    String passwordIsIncorrect();

    String pageIsEmpty();

    String fieldCannotBeEmpty();

    String invalidImage();

    String nameTaken();

    String pageNotFound();

    String invalidValue();

    String invalidUsernameOrEmail();

    String pageIsForbidden();

    String categoryNameTaken();
}
