package com.cyecize.mishmash;

import com.cyecize.summer.areas.routing.interfaces.UploadedFile;
import com.cyecize.summer.areas.validation.constraints.MinLength;
import com.cyecize.summer.areas.validation.constraints.NotEmpty;
import com.cyecize.summer.areas.validation.constraints.NotNull;

public class TestBindingModel {

    @NotNull
    @MinLength(length = 1)
    private UploadedFile uploadedFile;

    public UploadedFile getUploadedFile() {
        return this.uploadedFile;
    }
}
