package com.cyecize.mishmash.areas.channels.bindingModels.validators;

import com.cyecize.mishmash.areas.channels.services.CategoryService;
import com.cyecize.summer.areas.validation.interfaces.ConstraintValidator;
import com.cyecize.summer.common.annotations.Component;

@Component
public class UniqueCategoryNameValidator implements ConstraintValidator<UniqueCategoryName, String> {

    private final CategoryService categoryService;

    public UniqueCategoryNameValidator(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @Override
    public boolean isValid(String s, Object o) {
        if (s == null)
            s = "";
        return this.categoryService.findOneByName(s) == null;
    }
}
