package com.cyecize.mishmash.utils;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.channels.entities.ChannelCategory;
import com.cyecize.mishmash.areas.language.services.LocalLanguage;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.mishmash.areas.users.services.UserService;
import com.cyecize.summer.areas.template.annotations.TemplateService;
import com.cyecize.summer.common.annotations.Service;

import java.util.List;

@Service
@TemplateService(serviceNameInTemplate = "util")
public class TwigUtil {

    private final LocalLanguage localLanguage;

    public TwigUtil(LocalLanguage localLanguage) {
        this.localLanguage = localLanguage;
    }

    public String catName(ChannelCategory channelCategory) {
        switch (localLanguage.locale().toUpperCase()) {
            case "BG":
                return channelCategory.getCyrillicName();
            default:
                return channelCategory.getLatinName();
        }
    }

    public boolean isUserFollowing(User user, Channel channel) {
        return user.getSubscribedChannels().stream().anyMatch(ch -> ch.getId().equals(channel.getId()));
    }

    public boolean hasUserRole(User user, String role) {
        return user.getRoles().stream().anyMatch(r -> r.getAuthority().equalsIgnoreCase(role));
    }

}
