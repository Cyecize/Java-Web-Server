package com.cyecize.mishmash.areas.channels.viewModels;

public class UnsubChannelViewModel {

    private String username;

    private String channelName;

    private Long id;
}
