This is the same example, but with javache embedded.

The idea is that now you can just import the project and run it without having to package a jar file
and load it to Javache's webapps.

It is tested on IntelliJ only.