package com.cyecize.mishmash.areas.channels.controllers;

import com.cyecize.mishmash.areas.channels.bindingModels.ChannelBindingModel;
import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.channels.services.CategoryService;
import com.cyecize.mishmash.areas.channels.services.ChannelService;
import com.cyecize.mishmash.areas.channels.viewModels.CreateChannelViewModel;
import com.cyecize.mishmash.areas.channels.viewModels.UnsubChannelViewModel;
import com.cyecize.mishmash.areas.language.services.LocalLanguage;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.mishmash.areas.users.services.UserService;
import com.cyecize.mishmash.controllers.BaseController;
import com.cyecize.mishmash.utils.ModelMerger;
import com.cyecize.summer.areas.routing.exceptions.HttpNotFoundException;
import com.cyecize.summer.areas.security.annotations.PreAuthorize;
import com.cyecize.summer.areas.security.models.Principal;
import com.cyecize.summer.areas.validation.annotations.Valid;
import com.cyecize.summer.areas.validation.interfaces.BindingResult;
import com.cyecize.summer.common.annotations.Controller;
import com.cyecize.summer.common.annotations.routing.GetMapping;
import com.cyecize.summer.common.annotations.routing.PathVariable;
import com.cyecize.summer.common.annotations.routing.PostMapping;
import com.cyecize.summer.common.annotations.routing.RequestMapping;
import com.cyecize.summer.common.models.ModelAndView;
import com.cyecize.summer.common.models.RedirectAttributes;

@Controller
@PreAuthorize(role = "ROLE_USER")
@RequestMapping("/channels")
public class ChannelController extends BaseController {

    private static final String CHANNEL_WITH_ID_NOT_FOUND_FORMAT = "Channel with id %d was not found.";

    private final UserService userService;

    private final CategoryService categoryService;

    private final ChannelService channelService;

    private final ModelMerger modelMapper;

    public ChannelController(LocalLanguage localLanguage, UserService userService, CategoryService categoryService, ChannelService channelService, ModelMerger modelMapper) {
        super(localLanguage);
        this.userService = userService;
        this.categoryService = categoryService;
        this.channelService = channelService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/{id}/")
    public ModelAndView channelDetails(@PathVariable("id") Long id) throws HttpNotFoundException {
        Channel channel = this.channelService.findOneById(id);
        if (channel == null)
            throw new HttpNotFoundException(String.format(CHANNEL_WITH_ID_NOT_FOUND_FORMAT, id));
        return super.view("default/channel-details.twig", "channel", channel);
    }

    @GetMapping("/{channelId}/follow")
    public String followChannelAction(@PathVariable("channelId") Long channelId, Principal principal) throws HttpNotFoundException {
        Channel channel = this.channelService.findOneById(channelId);
        if (channel == null)
            throw new HttpNotFoundException(String.format(CHANNEL_WITH_ID_NOT_FOUND_FORMAT, channelId));
        this.channelService.followChannel(channel, this.userService.findOneByUsername(principal.getUser().getUsername()));
        return "redirect:/";
    }

    @GetMapping("/{channelId}/unfollow")
    public String unfollowChannelAction(@PathVariable("channelId") Long channelId, Principal principal) throws HttpNotFoundException {
        Channel channel = this.channelService.findOneById(channelId);
        if (channel == null)
            throw new HttpNotFoundException(String.format(CHANNEL_WITH_ID_NOT_FOUND_FORMAT, channelId));
        this.channelService.unfollowChannel(channel, this.userService.findOneByUsername(principal.getUser().getUsername()));
        return "redirect:/";
    }

    @PostMapping(value = "/{id}/unfollow", produces = "application/json")
    public UnsubChannelViewModel removeChannel(@PathVariable("id") Long id, Principal principal) throws HttpNotFoundException {
        Channel channel = this.channelService.findOneById(id);
        if (channel == null)
            throw new HttpNotFoundException(String.format(CHANNEL_WITH_ID_NOT_FOUND_FORMAT, id));

        User user = this.userService.findOneByUsername(principal.getUser().getUsername());
        this.channelService.unfollowChannel(channel, user);
        UnsubChannelViewModel viewModel = new UnsubChannelViewModel();
        this.modelMapper.merge(channel, viewModel);
        this.modelMapper.merge(user, viewModel);
        return viewModel;
    }

    @GetMapping("/followed")
    public ModelAndView myChannelsAction(Principal principal) {
        User user = this.userService.findOneByUsername(principal.getUser().getUsername());
        return super.view("default/followed-channels.twig", "channels", user.getSubscribedChannels());
    }

    @GetMapping("/create")
    @PreAuthorize(role = "ROLE_ADMIN")
    public ModelAndView createChannelGet() {
        return super.view("admin/channels/create-channel.twig", "viewModel", new CreateChannelViewModel(this.categoryService.findAll()));
    }

    @PostMapping("/create")
    @PreAuthorize(role = "ROLE_ADMIN")
    public String createChannelPost(@Valid ChannelBindingModel bindingModel, BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        redirectAttributes.addAttribute("model", bindingModel);

        if (bindingResult.hasErrors()) {
            return "redirect:/channels/create";
        }

        this.channelService.createChannel(bindingModel);
        return "redirect:/";
    }
}
