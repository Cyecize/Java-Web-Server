package com.cyecize.mishmash.areas.channels.services;

import com.cyecize.mishmash.areas.channels.bindingModels.ChannelBindingModel;
import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.channels.entities.Tag;
import com.cyecize.mishmash.areas.channels.repositories.ChannelRepository;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.summer.common.annotations.Service;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ChannelServiceImpl implements ChannelService {

    private final ChannelRepository channelRepository;

    private final ModelMapper modelMapper;

    private final TagService tagService;

    public ChannelServiceImpl(ChannelRepository channelRepository, ModelMapper modelMapper, TagService tagService) {
        this.channelRepository = channelRepository;
        this.modelMapper = modelMapper;
        this.tagService = tagService;
    }

    @Override
    public void followChannel(Channel channel, User user) {
        user.addChannel(channel);
    }

    @Override
    public void unfollowChannel(Channel channel, User user) {
        user.removeChannel(channel);
    }

    @Override
    public void createChannel(ChannelBindingModel bindingModel) {
        Channel channel = this.modelMapper.map(bindingModel, Channel.class);

        for (Tag tag : this.tagService.findOrCreateTags(bindingModel.getTagNames())) {
            channel.addTag(tag);
        }

        this.channelRepository.persist(channel);
    }

    @Override
    public Channel findOneById(Long id) {
        return this.channelRepository.find(id);
    }

    @Override
    public Channel findOneByName(String name) {
        return this.channelRepository.findOneByName(name);
    }

    @Override
    public List<Channel> findSuggested(List<Tag> tags, User user) {
        return this.filterSubbedChannels(this.channelRepository.findByIds(this.findSuggestedIds(tags)), user);
    }

    @Override
    public List<Channel> findOther(List<Tag> tags, User user) {
        return this.filterSubbedChannels(this.channelRepository.findByIds(this.channelRepository.findOther(this.findSuggestedIds(tags))), user);
    }

    @Override
    public List<Channel> findAll() {
        return this.channelRepository.findAll();
    }

    private List<Long> findSuggestedIds(List<Tag> tags) {
        List<Long> channelIds = new ArrayList<>();

        for (Tag tag : tags) {
            List<Long> channels = this.channelRepository.findByTagAndUserNotSubbedIds(tag);
            for (Long channel : channels) {
                if (!channelIds.contains(channel))
                    channelIds.add(channel);
            }
        }
        return channelIds;
    }

    private List<Channel> filterSubbedChannels(List<Channel> channels, User user) {
        return channels.stream()
                .filter(c -> c.getSubscribers().stream().noneMatch(sub -> sub.getId().equals(user.getId())))
                .collect(Collectors.toList());
    }


}
