package com.cyecize.mishmash.areas.users.services;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.users.bindingModels.UserRegisterBindingModel;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.mishmash.areas.users.enums.RoleType;
import com.cyecize.mishmash.areas.users.repositories.UserRepository;
import com.cyecize.summer.common.annotations.Service;
import org.mindrot.jbcrypt.BCrypt;
import org.modelmapper.ModelMapper;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    private final RoleService roleService;

    private final ModelMapper modelMapper;

    public UserServiceImpl(UserRepository userRepository, RoleService roleService, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.roleService = roleService;
        this.modelMapper = modelMapper;
    }

    @Override
    public void promote(User user) {
        user.addRole(this.roleService.findOneByRoleType(RoleType.ROLE_ADMIN.name()));
    }

    @Override
    public void createUser(UserRegisterBindingModel bindingModel) {
        User user = this.modelMapper.map(bindingModel, User.class);
        user.addRole(this.roleService.findOneByRoleType(RoleType.ROLE_USER.name()));
        if (this.userRepository.count() < 1) {
            user.addRole(this.roleService.findOneByRoleType(RoleType.ROLE_ADMIN.name()));
        }
        user.setPassword(BCrypt.hashpw(user.getPassword(), BCrypt.gensalt()));
        this.userRepository.persist(user);
    }

    @Override
    public User findOneById(Long id) {
        return this.userRepository.find(id);
    }

    @Override
    public User findOneByUsername(String username) {
        return this.userRepository.findOneByUsername(username);
    }

    @Override
    public User findOneByUsernameOrEmail(String handle) {
        return this.userRepository.findOneByUsernameOrEmail(handle);
    }

    @Override
    public List<User> findByChannel(Channel channel) {
        return this.userRepository.findByChannel(channel);
    }

    @Override
    public List<User> findAll() {
        return this.userRepository.findAll();
    }
}
