package com.cyecize.mishmash.config;

import com.cyecize.mishmash.utils.ModelMerger;
import com.cyecize.summer.areas.security.confighandlers.RedirectToLoginUrlHandler;
import com.cyecize.summer.areas.security.models.SecuredArea;
import com.cyecize.summer.areas.security.models.SecurityConfig;
import com.cyecize.summer.common.annotations.Bean;
import com.cyecize.summer.common.annotations.BeanConfig;
import org.modelmapper.ModelMapper;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

@BeanConfig
public class BeanCfg {

    public BeanCfg() {

    }

    @Bean
    public SecurityConfig getSecurityConfig() {
        return new SecurityConfig()
                .setLoginURL("/login")
                .setLogoutURL("/logout")
                .setLogoutRedirectURL("/");
    }

    @Bean
    public ModelMapper getModelMapper() {
        return new ModelMapper();
    }

    @Bean
    public ModelMerger getModelMerger() {
        return new ModelMerger();
    }

    @Bean
    public EntityManagerFactory entityManagerFactory() {
        return Persistence.createEntityManagerFactory("bdzSummer");
    }
}
