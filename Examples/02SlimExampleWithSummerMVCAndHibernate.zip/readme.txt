This application is utilizing Summer MVC Framework with fully set up environment:
Javache (Broccolina, Toyote)
Libraries and put in lib folder.
Application is loaded in webapps folder with default db password of toor.

It also uses hibernate and ModelMapper.
the default password for the db is toor and the address is localhost:3306 user - root

This application is a part of an exam in a software university but I used it here to demonstrate the functionalities
of the MVC framework.

a .docx file with a short app description will be present. NOTE that the application's functionalities are 
extended from the description. For example the final app has 2 languages to show how interceptors work.

It also packs:
Custom Data Binders
Custom Validators
Custom Services/TempalteServices and more.

You can also test the file upload functionality on the home page after you login.
The uploaded file can be then found in the assets dir.

In the source code you can see that I am also using javache embedded while working on the application, but javache embedded
is not required once we put the app on the standalone server.

You can open the project in intellij and see how the artifact is created. (Outdated since update 2022 11 29, Use maven for that)


This example now supports deployment with Docker.
There is an attached Dockerfile.
Pom.xml is modified to build a self executable jar file with all dependencies.
If you want to make your javache app deployable to docker, check out the commit with name: "Add support for Docker deployment"

Update:
This slimmer version of example 2 does not have git repo and the files inside lib folder are removed. If you want to run this app, you need to build javache
from 'automated-build-scripts/build-and-deploy.bat' then go to 'build-output' and copy 'summer-1.3.jar' and 'javache-embedded-1.3.jar' in the lib folder (I have added a readme).

Update 2022 11 29:
This example now has maven plugins to create a .jar file that works with Standard Javache out of the box, just like the artifact in IntelliJ.
Read the pom.xml as it has plugins for both docker / executable and now for Standard Javache. 
You may need to comment out one of the two in order to create a Docker / Standard Javache build.
