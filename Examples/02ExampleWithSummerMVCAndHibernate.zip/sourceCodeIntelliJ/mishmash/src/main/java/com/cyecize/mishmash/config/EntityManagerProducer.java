package com.cyecize.mishmash.config;

import com.cyecize.summer.common.annotations.Bean;
import com.cyecize.summer.common.annotations.BeanConfig;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

@BeanConfig
public class EntityManagerProducer {

    private final EntityManagerFactory emf;

    public EntityManagerProducer(EntityManagerFactory emf) {
        this.emf = emf;
    }

    @Bean
    public EntityManager entityManager() {
        return this.emf.createEntityManager();
    }
}
