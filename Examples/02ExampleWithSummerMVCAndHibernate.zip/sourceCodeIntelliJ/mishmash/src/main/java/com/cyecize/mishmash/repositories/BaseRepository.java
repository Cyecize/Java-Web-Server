package com.cyecize.mishmash.repositories;

import com.cyecize.mishmash.repositories.utils.RepositoryActionInvoker;
import com.cyecize.mishmash.repositories.utils.RepositoryActionResult;
import com.cyecize.mishmash.repositories.utils.RepositoryActionResultImpl;

import javax.persistence.*;

public class BaseRepository {

    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("bdzSummer");

    private EntityTransaction transaction;

    protected EntityManager entityManager;

    protected BaseRepository() {
        this.entityManager = emf.createEntityManager();
    }

    private void initTransaction() {
        if (this.transaction != null && this.transaction.isActive()) {
            throw new IllegalArgumentException("Transaction is active!");
        }

        this.transaction = this.entityManager.getTransaction();
        this.transaction.begin();
    }

    private void commitTransaction() {
        if (this.transaction == null || !this.transaction.isActive()) {
            throw new IllegalArgumentException("Transaction is null or inactive!");
        }

        this.transaction.commit();
    }

    protected RepositoryActionResult execute(RepositoryActionInvoker invoker) {
        RepositoryActionResult actionResult = new RepositoryActionResultImpl();

        try {
            this.initTransaction();
            invoker.invoke(actionResult);
            this.commitTransaction();
        } catch (Exception e) {
            if (this.transaction != null) {
                this.transaction.rollback();
            }
            e.printStackTrace();
        }

        return actionResult;
    }

    public void persist(Object entity) {
        if (!entity.getClass().isAnnotationPresent(Entity.class))
            return;
        this.execute((repositoryActionResult -> {
            this.entityManager.persist(entity);
            this.entityManager.flush();
        }));
    }

    public void merge(Object entity) {
        if (!entity.getClass().isAnnotationPresent(Entity.class))
            return;
        this.execute(repositoryActionResult -> {
            this.entityManager.merge(entity);
            this.entityManager.flush();
        });
    }
}
