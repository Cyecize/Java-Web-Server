This application is utilizing Summer MVC Framework with fully set up environment:
Javache (Broccolina, Toyote)
Libraries and put in lib folder.
Application is loaded in webapps folder with default db password of toor.

It also uses hibernate and ModelMapper.
the default password for the db is toor and the address is localhost:3306 user - root

I will provide a .jar file with password 1234 and root, but if your password is different, you will need 
to compile your own jar, which will not be a problem since I am leaving the app code as well.

This application is a part of an exam in a software university but I used it here to demonstrate the functionalities
of the summer framework.

a .docx file with a short app description will be present. NOTE that the application's functionalities are 
extended from the description. For example the final app has 2 languages to show how interceptors work.

It also packs:
Custom Data Binders
Custom Validators
Custom Services/TempalteServices and more.

