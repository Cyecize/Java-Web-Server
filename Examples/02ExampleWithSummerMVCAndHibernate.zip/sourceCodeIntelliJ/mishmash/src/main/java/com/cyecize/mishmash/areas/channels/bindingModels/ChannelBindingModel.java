package com.cyecize.mishmash.areas.channels.bindingModels;

import com.cyecize.mishmash.areas.channels.bindingModels.validators.UniqueChannelName;
import com.cyecize.mishmash.areas.channels.entities.ChannelCategory;
import com.cyecize.summer.areas.validation.constraints.MaxLength;
import com.cyecize.summer.areas.validation.constraints.MinLength;
import com.cyecize.summer.areas.validation.constraints.NotNull;

import java.util.List;

public class ChannelBindingModel {

    @NotNull(message = "fieldCannotBeEmpty")
    @MinLength(length = 4, message = "invalidValue")
    @MaxLength(length = 50, message = "invalidValue")
    @UniqueChannelName
    private String name;

    @MaxLength(length = 255, message = "invalidValue")
    private String description;

    @NotNull
    private List<String> tagNames;

    @NotNull(message = "fieldCannotBeEmpty")
    private ChannelCategory category;

    public ChannelBindingModel() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getTagNames() {
        return tagNames;
    }

    public void setTagNames(List<String> tagNames) {
        this.tagNames = tagNames;
    }

    public ChannelCategory getCategory() {
        return category;
    }

    public void setCategory(ChannelCategory category) {
        this.category = category;
    }
}
