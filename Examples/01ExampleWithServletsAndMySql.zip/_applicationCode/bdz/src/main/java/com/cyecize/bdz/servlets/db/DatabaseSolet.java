package com.cyecize.bdz.servlets.db;

import com.cyecize.bdz.constants.WebConstants;
import com.cyecize.http.HttpStatus;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;
import com.google.gson.Gson;

@WebSolet("/database")
public class DatabaseSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        var session = request.getSession().getAttributes();
        response.setStatusCode(HttpStatus.SEE_OTHER);
        response.setContent(" ".getBytes());
        if (!session.containsKey(WebConstants.USERNAME_SESSION_ID)) {
            response.addHeader("Location", "/login");
            return;
        }

        if (!session.containsKey(WebConstants.DB_PROPERTIES_SESSION_ID) || session.get(WebConstants.DB_CONNECTION_SESSION_ID) == null) {
            response.addHeader("Location", "/db-settings.html");
            return;
        }

        response.addHeader("Location", "/db-panel.html");
//        response.setContent(new Gson().toJson(session.get(WebConstants.DB_PROPERTIES_SESSION_ID)).getBytes());
    }
}
