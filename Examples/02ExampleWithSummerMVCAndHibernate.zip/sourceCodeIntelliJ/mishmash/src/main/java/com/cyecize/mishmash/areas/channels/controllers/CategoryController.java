package com.cyecize.mishmash.areas.channels.controllers;

import com.cyecize.mishmash.areas.channels.bindingModels.CategoryBindingModel;
import com.cyecize.mishmash.areas.channels.services.CategoryService;
import com.cyecize.mishmash.areas.language.services.LocalLanguage;
import com.cyecize.mishmash.controllers.BaseController;
import com.cyecize.summer.areas.security.annotations.PreAuthorize;
import com.cyecize.summer.areas.validation.annotations.Valid;
import com.cyecize.summer.areas.validation.interfaces.BindingResult;
import com.cyecize.summer.common.annotations.Controller;
import com.cyecize.summer.common.annotations.routing.GetMapping;
import com.cyecize.summer.common.annotations.routing.PostMapping;
import com.cyecize.summer.common.annotations.routing.RequestMapping;
import com.cyecize.summer.common.models.ModelAndView;
import com.cyecize.summer.common.models.RedirectAttributes;

@Controller
@PreAuthorize(role = "ROLE_ADMIN")
@RequestMapping("/categories")
public class CategoryController extends BaseController {

    private final CategoryService categoryService;

    public CategoryController(LocalLanguage localLanguage, CategoryService categoryService) {
        super(localLanguage);
        this.categoryService = categoryService;
    }

    @GetMapping("/observe")
    public ModelAndView allCategories() {
        return super.view("/admin/categories/all-categories.twig", "categories", this.categoryService.findAll());
    }

    @GetMapping("/create")
    public ModelAndView createCategoryGet() {
        return super.view("/admin/categories/create-category.twig");
    }

    @PostMapping("/create")
    public ModelAndView createCategoryPost(@Valid CategoryBindingModel bindingModel, BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        redirectAttributes.addAttribute("model", bindingModel);

        if (bindingResult.hasErrors()) {
            return super.redirect("create");
        }

        this.categoryService.createCategory(bindingModel);
        return super.redirect("observe");
    }
}
