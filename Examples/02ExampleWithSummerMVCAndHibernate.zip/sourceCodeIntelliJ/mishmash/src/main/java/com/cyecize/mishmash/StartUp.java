package com.cyecize.mishmash;

import com.cyecize.javache.JavacheConfigValue;
import com.cyecize.javache.embedded.JavacheEmbedded;
import com.cyecize.summer.DispatcherSolet;
import com.cyecize.summer.SummerBootApplication;

import java.util.HashMap;

public class StartUp extends DispatcherSolet {
    public StartUp() {
        SummerBootApplication.run(this);
    }

    public static void main(String[] args) {
        JavacheEmbedded.startServer(8000, new HashMap<>() {{
            put(JavacheConfigValue.TOYOTE_RESOURCE_HANDLER_ORDER.name(), 2);
            put(JavacheConfigValue.BROCCOLINA_SOLET_DISPATCHER_ORDER.name(), 1);
        }}, StartUp.class);
    }
}
