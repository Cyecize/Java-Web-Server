package com.cyecize.bdz.servlets.db;

import com.cyecize.bdz.constants.WebConstants;
import com.cyecize.bdz.entities.DbProperties;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

@WebSolet("/database/configure")
public class ConfigureDatabaseSolet extends BaseHttpSolet {

    @Override
    protected void doPost(HttpSoletRequest request, HttpSoletResponse response) {
        var session = request.getSession().getAttributes();
        if (!session.containsKey(WebConstants.USERNAME_SESSION_ID)) {
            response.sendRedirect(super.createRoute("/login"));
            return;
        }
        var params = request.getBodyParameters();
        DbProperties properties = new DbProperties(params.get("server"), params.get("port"), params.get("user"), params.get("password"), params.get("database"));
        session.put(WebConstants.DB_PROPERTIES_SESSION_ID, properties);
        if (session.containsKey(WebConstants.DB_CONNECTION_SESSION_ID) && session.get(WebConstants.DB_CONNECTION_SESSION_ID) != null) {
            try {
                ((Connection) session.get(WebConstants.DB_CONNECTION_SESSION_ID)).close();
                session.put(WebConstants.DB_CONNECTION_SESSION_ID, null);
                System.out.println("Closed previous connection");
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                ex.printStackTrace();
            }
        }
        try {
            Properties authProps = new Properties();
            authProps.setProperty("user", properties.username);
            if (!properties.password.trim().equals("")) {
                authProps.setProperty("password", properties.password);
            }
            Connection connection = DriverManager.getConnection(String.format("jdbc:mysql://%s:%s/%s?useSSL=false&createDatabaseIfNotExist=true",
                    properties.server,
                    properties.port,
                    properties.database
            ), authProps);
            connection.prepareStatement(" CREATE TABLE IF NOT EXISTS entries (\n" +
                    "\tid INT(11) AUTO_INCREMENT PRIMARY KEY,\n" +
                    "    entry_name VARCHAR(255) NOT NULL\n" +
                    " );\n" +
                    " ").execute();

            session.put(WebConstants.DB_CONNECTION_SESSION_ID, connection);

        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            response.sendRedirect(super.createRoute("/db-settings.html"));
            return;
        }
        response.sendRedirect(super.createRoute("/database"));
    }
}
