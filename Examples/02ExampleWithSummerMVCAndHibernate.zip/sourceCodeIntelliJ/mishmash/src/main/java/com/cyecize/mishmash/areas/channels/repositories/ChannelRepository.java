package com.cyecize.mishmash.areas.channels.repositories;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.channels.entities.Tag;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ChannelRepository extends BaseRepository {

    public Channel findOneById(Long id) {
        return super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery("SELECT c FROM Channel c WHERE c.id = :cid", Channel.class)
                    .setParameter("cid", id)
                    .getResultStream().findFirst().orElse(null)
            );
        }).getResult();
    }

    public Channel findOneByName(String name) {
        return super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery("SELECT c FROM Channel c WHERE c.name =:cName", Channel.class)
                    .setParameter("cName", name)
                    .getResultStream().findFirst().orElse(null)
            );
        }).getResult();
    }

    public List<Long> findByTagAndUserNotSubbedIds(Tag tag) {
        return super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery(
                    "SELECT DISTINCT c.id FROM Channel c JOIN c.tags ct WHERE ct = :tag", Long.class)
                    .setParameter("tag", tag)
                    .getResultList()
            );
        }).getResult();
    }

    public List<Long> findOther(List<Long> suggested) {
        if (suggested.size() < 1) {
            suggested.add(-1L);
        }

        return super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery("SELECT c.id FROM Channel c LEFT JOIN c.subscribers cs WHERE c.id NOT IN :ids", Long.class)
                    .setParameter("ids", suggested)
                    .getResultList()
            );
        }).getResult();
    }

    public List<Channel> findByIds(List<Long> ids) {
        if (ids.size() < 1) {
            return new ArrayList<>();
        }
        return super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery("SELECT c FROM Channel c WHERE c.id IN :ids", Channel.class)
                    .setParameter("ids", ids)
                    .getResultList()
            );
        }).getResult();
    }

    public List<Channel> findAll() {
        return super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery("SELECT c FROM Channel c", Channel.class)
                    .getResultList()
            );
        }).getResult();
    }

}
