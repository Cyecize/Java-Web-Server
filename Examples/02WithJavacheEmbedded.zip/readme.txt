Example same as 02, but with javache embedded server.
You can see that the size of the file has been redurect significantly.

It is also quite easier to run and change the database password.

It is also compatible with the real javache server.
For more datails you can read the documentation for Summer MVC - Get Started
or the documentation for Javache if it is out by the time you are reading this.