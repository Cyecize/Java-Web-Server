package com.cyecize.mishmash.areas.channels.viewModels;

import com.cyecize.mishmash.areas.channels.entities.ChannelCategory;

import java.util.List;

public class CreateChannelViewModel {

    private final List<ChannelCategory> categories;

    public CreateChannelViewModel(List<ChannelCategory> categories) {
        this.categories = categories;
    }

    public List<ChannelCategory> getCategories() {
        return categories;
    }
}
