package com.cyecize.mishmash.areas.channels.entities;

import javax.persistence.*;

@Entity
@Table(name = "channel_categories")
public class ChannelCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, updatable = false, nullable = false)
    private Long id;

    @Column(name = "latin_name", unique = true, nullable = false)
    private String latinName;

    @Column(name = "cyrillic_name", unique = true, nullable = false)
    private String cyrillicName;

    public ChannelCategory() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLatinName() {
        return latinName;
    }

    public void setLatinName(String latinName) {
        this.latinName = latinName;
    }

    public String getCyrillicName() {
        return cyrillicName;
    }

    public void setCyrillicName(String cyrillicName) {
        this.cyrillicName = cyrillicName;
    }
}
