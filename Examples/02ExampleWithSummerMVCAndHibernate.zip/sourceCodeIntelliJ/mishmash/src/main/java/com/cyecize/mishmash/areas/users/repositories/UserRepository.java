package com.cyecize.mishmash.areas.users.repositories;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;

import java.util.List;

@Service
public class UserRepository extends BaseRepository<User, Long> {

    public User findOneByUsername(String username) {
        return super.queryBuilderSingle((criteriaQuery, root) -> criteriaQuery.where(
                super.criteriaBuilder.equal(root.get("username"), username)
        ));
    }

    public User findOneByUsernameOrEmail(String handle) {

        return super.queryBuilderSingle((userCriteriaQuery, userRoot) -> userCriteriaQuery.where(
                super.criteriaBuilder.or(
                        super.criteriaBuilder.equal(userRoot.get("email"), handle),
                        super.criteriaBuilder.equal(userRoot.get("username"), handle)
                )
        ));
    }

    public List<User> findByChannel(Channel channel) {
        return super.executeList(() -> super.entityManager.createQuery(
                "SELECT u FROM User u JOIN u.subscribedChannels sc WHERE sc = :channel", User.class)
                .setParameter("channel", channel)
                .getResultList()
        );
    }
}
