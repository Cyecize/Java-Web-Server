package com.cyecize.mishmash.areas.language.languagePacks;

import com.cyecize.mishmash.areas.language.enums.LanguageLocaleType;

public class DictionaryEnImpl implements Dictionary {
    public static final String HOME = "Home";
    public static final String CONTACTS = "Contacts";
    public static final String ABOUT_US = "About us";
    public static final String LOGIN = "Login";
    public static final String REGISTER = "Register";
    public static final String LOGOUT = "Logout";
    public static final String GO = "Go";
    public static final String MENU = "Menu";
    public static final String USERNAME_IS_NULL = "Username is empty";
    public static final String USERNAME_INVALID_FORMAT = "Invalid username format";
    public static final String USERNAME_TAKEN = "Username is in use";
    public static final String EMAIL_IS_NULL = "Email is empty";
    public static final String EMAIL_IS_IN_USE = "Email is in use";
    public static final String PASSWORDS_DO_NOT_MATCH = "Passwords do not match";
    public static final String INCORRECT_PASSWORD = "Incorrect password";
    public static final String USERNAME = "Username";
    public static final String EMAIL = "Email";
    public static final String PASSWORD = "Password";
    public static final String PROFILE = "Profile";
    public static final String DETAILS = "Details";
    public static final String PAGE_IS_EMPTY = "This page is empty.";
    public static final String FIELD_CANNOT_BE_EMPTY = "Field cannot be empty";
    public static final String BACK = "Back";
    public static final String INVALID_IMAGE = "Invalid image";
    public static final String NAME_TAKEN = "Name taken";
    public static final String REMOVE = "Remove";
    public static final String NAME = "Name";
    public static final String DESCRIPTION = "Description";
    public static final String TITLE = "Title";
    public static final String PAGE_NOT_FOUND = "Page Not Found";
    public static final String INVALID_VALUE = "Invalid value";
    public static final String INVALID_USERNAME_OR_EMAIL = "Invalid Username or Email";
    public static final String PAGE_IS_FORBIDDEN = "Page is forbidden.";
    public static final String FOLLOWED = "Followed";
    public static final String FOLLOWERS = "Followers";
    public static final String CHANNEL = "Channel";
    public static final String CATEGORY = "Category";
    public static final String ACTIONS = "Actions";
    public static final String CREATE_CHANNEL = "Create Channel";
    public static final String CATEGORIES = "Categories";
    public static final String CREATE_CATEGORY = "New Category";
    public static final String CATEGORY_NAME_TAKEN = "Name taken";
    public static final String LATIN_NAME = "Latin name";
    public static final String CYRILLIC_NAME = "Cyrillic name";
    public static final String SHOW_ALL = "Show all";
    public static final String CHANNELS = "Channels";
    public static final String TAGS = "Tags";
    public static final String ADD_TAG = "New tag";
    public static final String WELCOME  = "Welcome";
    public static final String OTHER  = "Other";
    public static final String SUGGESTED  = "Suggested";
    public static final String FOLLOWING  = "Following";
    public static final String FOLLOW  = "Follow";


    public String follow() {
        return FOLLOW;
    }

    public String following() {
        return FOLLOWING;
    }

    public String suggested() {
        return SUGGESTED;
    }

    public String other() {
        return OTHER;
    }

    public String welcome() {
        return WELCOME;
    }

    public String channels() {
        return CHANNELS;
    }

    public String tags() {
        return TAGS;
    }

    public String addTag() {
        return ADD_TAG;
    }

    public String showAll() {
        return SHOW_ALL;
    }

    public String categoryNameTaken() {
        return CATEGORY_NAME_TAKEN;
    }

    public String latinName() {
        return LATIN_NAME;
    }

    public String cyrillicName() {
        return CYRILLIC_NAME;
    }

    public String categories() {
        return CATEGORIES;
    }

    public String createCategory() {
        return CREATE_CATEGORY;
    }

    public String createChannel() {
        return CREATE_CHANNEL;
    }

    public String followers() {
        return FOLLOWERS;
    }

    public String channel() {
        return CHANNEL;
    }

    public String category() {
        return CATEGORY;
    }

    public String actions() {
        return ACTIONS;
    }

    public String followed() {
        return FOLLOWED;
    }

    public String pageIsForbidden() {
        return PAGE_IS_FORBIDDEN;
    }

    public String invalidUsernameOrEmail() {
        return INVALID_USERNAME_OR_EMAIL;
    }

    public String invalidValue() {
        return INVALID_VALUE;
    }

    public String pageNotFound() {
        return PAGE_NOT_FOUND;
    }

    public String title() {
        return TITLE;
    }

    public String name() {
        return NAME;
    }

    public String description() {
        return DESCRIPTION;
    }

    public String remove() { return REMOVE; }

    public String nameTaken() {
        return NAME_TAKEN;
    }

    public String invalidImage() {
        return INVALID_IMAGE;
    }

    public String back() {
        return BACK;
    }

    public String fieldCannotBeEmpty() {
        return FIELD_CANNOT_BE_EMPTY;
    }

    public String pageIsEmpty() {
        return PAGE_IS_EMPTY;
    }

    public String details() { return DETAILS; }

    public String profile() {
        return PROFILE;
    }

    public String usernameIsNull() {
        return USERNAME_IS_NULL;
    }

    public String usernameInvalidFormat() {
        return USERNAME_INVALID_FORMAT;
    }

    public String usernameTaken() {
        return USERNAME_TAKEN;
    }

    public String emailIsNull() {
        return EMAIL_IS_NULL;
    }

    public String emailTaken() {
        return EMAIL_IS_IN_USE;
    }

    public String passwordLengthIsLessThan() {
        return "Password is less than " + 6 + " characters long";
    }

    public String passwordsDoNotMatch() {
        return PASSWORDS_DO_NOT_MATCH;
    }

    public String passwordIsIncorrect() {
        return INCORRECT_PASSWORD;
    }

    public LanguageLocaleType getLocaleType() {
        return LanguageLocaleType.EN;
    }

    public String home() {
        return HOME;
    }

    public String contacts() {
        return CONTACTS;
    }

    public String aboutUs() {
        return ABOUT_US;
    }

    public String login() {
        return LOGIN;
    }

    public String register() {
        return REGISTER;
    }

    public String logout() {
        return LOGOUT;
    }

    public String go() {
        return GO;
    }

    public String menu() {
        return MENU;
    }

    public String username() {
        return USERNAME;
    }

    public String email() {
        return EMAIL;
    }

    public String password() {
        return PASSWORD;
    }
}
