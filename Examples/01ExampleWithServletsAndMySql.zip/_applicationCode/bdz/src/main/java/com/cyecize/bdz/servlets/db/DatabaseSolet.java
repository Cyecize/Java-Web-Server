package com.cyecize.bdz.servlets.db;

import com.cyecize.bdz.constants.WebConstants;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;


@WebSolet("/database")
public class DatabaseSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        final var session = request.getSession().getAttributes();
        if (!session.containsKey(WebConstants.USERNAME_SESSION_ID)) {
            response.sendRedirect(super.createRoute("/login"));
            return;
        }

        if (!session.containsKey(WebConstants.DB_PROPERTIES_SESSION_ID) || session.get(WebConstants.DB_CONNECTION_SESSION_ID) == null) {
            response.sendRedirect(super.createRoute("/db-settings.html"));
            return;
        }

        response.sendRedirect(super.createRoute("/db-panel.html"));
//        response.setContent(new Gson().toJson(session.get(WebConstants.DB_PROPERTIES_SESSION_ID)).getBytes());
    }
}
