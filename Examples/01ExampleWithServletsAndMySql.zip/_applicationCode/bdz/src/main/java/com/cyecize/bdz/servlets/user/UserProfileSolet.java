package com.cyecize.bdz.servlets.user;

import com.cyecize.bdz.constants.WebConstants;
import com.cyecize.http.HttpStatus;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;

@WebSolet("/logged-user/profile")
public class UserProfileSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        if (!request.getSession().getAttributes().containsKey(WebConstants.USERNAME_SESSION_ID)) {
            response.sendRedirect(super.createRoute("/login"));
        } else {
            response.sendRedirect(super.createRoute("/user-details.html"));
        }
    }
}
