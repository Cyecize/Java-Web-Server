package com.cyecize.mishmash.areas.home.viewModels;

import com.cyecize.mishmash.areas.channels.entities.Channel;

import java.util.List;

public class HomeViewModel {

    private List<Channel> myChannels;

    private List<Channel> suggestedChannels;

    private List<Channel> otherChannels;

    public HomeViewModel(List<Channel> myChannels, List<Channel> suggestedChannels, List<Channel> otherChannels) {
        this.myChannels = myChannels;
        this.suggestedChannels = suggestedChannels;
        this.otherChannels = otherChannels;
    }

    public List<Channel> getMyChannels() {
        return myChannels;
    }

    public List<Channel> getOtherChannels() {
        return otherChannels;
    }

    public List<Channel> getSuggestedChannels() {
        return suggestedChannels;
    }
}
