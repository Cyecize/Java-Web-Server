package com.cyecize.bdz.servlets;

import com.cyecize.http.HttpStatus;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;

@WebSolet("/")
public class HomeSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        response.setContent(" ".getBytes());
        response.setStatusCode(HttpStatus.SEE_OTHER);
        response.addHeader("Location", "/index.html");
    }
}
