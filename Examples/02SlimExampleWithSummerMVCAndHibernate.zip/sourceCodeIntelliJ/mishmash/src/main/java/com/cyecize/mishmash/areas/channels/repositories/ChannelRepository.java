package com.cyecize.mishmash.areas.channels.repositories;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.channels.entities.Tag;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ChannelRepository extends BaseRepository<Channel, Long> {

    public Channel findOneByName(String name) {
        return super.queryBuilderSingle((channelCriteriaQuery, channelRoot) -> channelCriteriaQuery.where(
                super.criteriaBuilder.equal(channelRoot.get("name"), name)
        ));
    }

    public List<Long> findByTagAndUserNotSubbedIds(Tag tag) {
        return super.executeList(() ->
                        super.entityManager.createQuery("SELECT DISTINCT c.id FROM Channel c JOIN c.tags ct WHERE ct = :tag", Long.class)
                                .setParameter("tag", tag)
                                .getResultList(),
                Long.class
        );
    }

    public List<Long> findOther(List<Long> suggested) {
        if (suggested.size() < 1) {
            suggested.add(-1L);
        }

        return super.executeList(() ->
                        super.entityManager.createQuery("SELECT c.id FROM Channel c LEFT JOIN c.subscribers cs WHERE c.id NOT IN :ids", Long.class)
                                .setParameter("ids", suggested)
                                .getResultList(),
                Long.class);
    }

    public List<Channel> findByIds(List<Long> ids) {
        if (ids.size() < 1) {
            return new ArrayList<>();
        }

        return super.queryBuilderList((channelCriteriaQuery, channelRoot) -> channelCriteriaQuery.where(
                channelRoot.get("id").in(ids)
        ));
    }
}
