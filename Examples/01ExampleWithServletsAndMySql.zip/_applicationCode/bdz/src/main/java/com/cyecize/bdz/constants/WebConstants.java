package com.cyecize.bdz.constants;

public class WebConstants {

    public static final String USERNAME_SESSION_ID = "username";

    public static final String DB_PROPERTIES_SESSION_ID = "db";

    public static final String DB_CONNECTION_SESSION_ID = "connection";
}
