package com.cyecize.mishmash.areas.users.controllers;

import com.cyecize.mishmash.areas.language.services.LocalLanguage;
import com.cyecize.mishmash.areas.users.bindingModels.UserLoginBindingModel;
import com.cyecize.mishmash.areas.users.bindingModels.UserRegisterBindingModel;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.mishmash.areas.users.services.UserService;
import com.cyecize.mishmash.controllers.BaseController;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.summer.areas.security.annotations.PreAuthorize;
import com.cyecize.summer.areas.security.enums.AuthorizationType;
import com.cyecize.summer.areas.security.models.Principal;
import com.cyecize.summer.areas.validation.annotations.Valid;
import com.cyecize.summer.areas.validation.interfaces.BindingResult;
import com.cyecize.summer.areas.validation.models.FieldError;
import com.cyecize.summer.common.annotations.Controller;
import com.cyecize.summer.common.annotations.routing.GetMapping;
import com.cyecize.summer.common.annotations.routing.PostMapping;
import com.cyecize.summer.common.models.Model;
import com.cyecize.summer.common.models.ModelAndView;
import com.cyecize.summer.common.models.RedirectAttributes;
import org.mindrot.jbcrypt.BCrypt;

@Controller
@PreAuthorize(AuthorizationType.ANONYMOUS)
public class SecurityController extends BaseController {

    private final UserService userService;

    public SecurityController(LocalLanguage localLanguage, UserService userService) {
        super(localLanguage);
        this.userService = userService;
    }

    @GetMapping("/login")
    public ModelAndView loginGet(Model model, HttpSoletRequest request) {
        String referer = "/";
        if (request.getQueryParameters().containsKey("callback"))
            referer = request.getQueryParameters().get("callback");

        if (!model.hasAttribute("model")) {
            UserLoginBindingModel bindingModel = new UserLoginBindingModel();
            bindingModel.setReferrer(referer);
            model.addAttribute("model", bindingModel);
        }

        return super.view("security/login.twig");
    }

    @PostMapping("/login")
    public ModelAndView loginPost(@Valid UserLoginBindingModel bindingModel, BindingResult bindingResult, RedirectAttributes redirectAttributes, Principal principal) {
        redirectAttributes.addAttribute("model", bindingModel);

        if (bindingResult.hasErrors())
            return super.redirect("/login");

        User user = this.userService.findOneByUsernameOrEmail(bindingModel.getUsername());
        if (!BCrypt.checkpw(bindingModel.getPassword(), user.getPassword())) {
            bindingResult.addNewError(new FieldError("login", "password", super.localLanguage.errors().passwordIsIncorrect(), bindingModel.getPassword()));
            return super.redirect("/login");
        }

        principal.setUser(user);
        return super.redirect(bindingModel.getReferrer() != null ? bindingModel.getReferrer() : "/");
    }

    @GetMapping("/register")
    public ModelAndView registerGet() {
        return super.view("security/register.twig");
    }

    @PostMapping("/register")
    public ModelAndView registerPost(@Valid UserRegisterBindingModel bindingModel, BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        redirectAttributes.addAttribute("model", bindingModel);
        if (bindingResult.hasErrors()) {
            return super.redirect("/register");
        }
        this.userService.createUser(bindingModel);
        return super.redirect("/login");
    }
}
