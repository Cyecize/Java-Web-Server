package com.cyecize.bdz;

import com.cyecize.javache.embedded.JavacheEmbedded;

/**
 * Starting point for Javache Embedded.
 * This method will not be executed on the standalone server.
 */
public class StartUp {
    public static void main(String[] args) {
        JavacheEmbedded.startServer(8000, StartUp.class);
    }
}
