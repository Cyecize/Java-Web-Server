package com.cyecize.mishmash.areas.channels.entities;

import com.cyecize.mishmash.areas.users.entities.User;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "channels")
public class Channel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, unique = true, nullable = false)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "description")
    @Type(type = "text")
    private String description;

    @ManyToOne(targetEntity = ChannelCategory.class)
    @JoinColumn(name = "category_id", referencedColumnName = "id")
    private ChannelCategory category;

    @ManyToMany(targetEntity = Tag.class, cascade = CascadeType.REMOVE)
    @JoinTable(name = "channels_tags",
            joinColumns = @JoinColumn(name = "channel_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "tag_id", referencedColumnName = "id"))
    private List<Tag> tags;

    @ManyToMany(targetEntity = User.class, mappedBy = "subscribedChannels")
    private List<User> subscribers;

    public Channel() {
        this.tags = new ArrayList<>();
        this.subscribers = new ArrayList<>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ChannelCategory getCategory() {
        return category;
    }

    public void setCategory(ChannelCategory category) {
        this.category = category;
    }

    public List<Tag> getTags() {
        return tags;
    }

    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

    public List<User> getSubscribers() {
        return subscribers;
    }

    public void setSubscribers(List<User> subscribers) {
        this.subscribers = subscribers;
    }

    @Transactional
    public void addTag(Tag tag) {
        this.tags.add(tag);
        tag.getChannels().add(this);
    }

    @Transactional
    public void removeTag(Tag tag) {
        if (this.tags.contains(tag)) {
            this.tags.remove(tag);
            tag.getChannels().remove(this);
        }
    }
}
