package com.cyecize.bdz.servlets.user;

import com.cyecize.bdz.constants.WebConstants;
import com.cyecize.http.HttpStatus;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;

@WebSolet("/logged-user/profile")
public class UserProfileSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        response.setStatusCode(HttpStatus.SEE_OTHER);
        response.setContent(" ".getBytes());
        if (!request.getSession().getAttributes().containsKey(WebConstants.USERNAME_SESSION_ID)) {
            response.addHeader("Location", "/login");
        } else {
            response.addHeader("Location", "/user-details.html");
        }
    }
}
