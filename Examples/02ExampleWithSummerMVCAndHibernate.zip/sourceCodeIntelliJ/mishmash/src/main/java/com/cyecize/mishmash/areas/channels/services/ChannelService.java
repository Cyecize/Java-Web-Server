package com.cyecize.mishmash.areas.channels.services;

import com.cyecize.mishmash.areas.channels.bindingModels.ChannelBindingModel;
import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.channels.entities.Tag;
import com.cyecize.mishmash.areas.users.entities.User;

import java.util.List;

public interface ChannelService {

    void followChannel(Channel channel, User user);

    void unfollowChannel(Channel channel, User user);

    void createChannel(ChannelBindingModel bindingModel);

    Channel findOneById(Long id);

    Channel findOneByName(String name);

    List<Channel> findSuggested(List<Tag> tags, User user);

    List<Channel> findOther(List<Tag> tags, User user);

    List<Channel> findAll();
}
