package com.cyecize.mishmash.areas.users.repositories;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;

import java.util.List;

@Service
public class UserRepository extends BaseRepository {

    public void createUser(User user) {
        super.execute((actionResult) -> {
            super.entityManager.persist(user);
            super.entityManager.flush();
        });
    }

    public Long countOfUsers() {
        return (Long) super.execute((actionResult) -> {
            actionResult.setResult(
                    super.entityManager.createQuery("SELECT count (u) FROM User u")
                            .getSingleResult()
            );
        }).getResult();
    }

    public User findOneById(Long id) {
        return (User) super.execute((actionResult) -> {
            actionResult.setResult(
                    super.entityManager.createQuery("SELECT u FROM User u WHERE u.id = :uid", User.class)
                            .setParameter("uid", id)
                            .getResultStream().findFirst().orElse(null)
            );
        }).getResult();
    }

    public User findOneByUsername(String username) {
        return (User) super.execute((actionResult) -> {
            actionResult.setResult(
                    super.entityManager.createQuery("SELECT u FROM User u WHERE u.username = :username", User.class)
                            .setParameter("username", username)
                            .getResultStream().findFirst().orElse(null)
            );
        }).getResult();
    }

    public User findOneByUsernameOrEmail(String handle) {
        return (User) super.execute((actionResult) -> {
            actionResult.setResult(
                    super.entityManager.createQuery("SELECT u FROM User u WHERE u.username = :handle OR u.email = :handle", User.class)
                            .setParameter("handle", handle)
                            .getResultStream().findFirst().orElse(null)
            );
        }).getResult();
    }

    @SuppressWarnings("unchecked")
    public List<User> findByChannel(Channel channel) {
        return (List<User>) super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery(
                    "SELECT u FROM User u JOIN u.subscribedChannels sc WHERE sc = :channel", User.class)
                    .setParameter("channel", channel)
                    .getResultList()
            );
        }).getResult();
    }

    @SuppressWarnings("unchecked")
    public List<User> findAll() {
        return (List<User>) super.execute((actionResult) -> {
            actionResult.setResult(
                    super.entityManager.createQuery("SELECT u FROM User u", User.class)
                            .getResultList()
            );
        }).getResult();
    }

}
