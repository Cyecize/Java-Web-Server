package com.cyecize.mishmash.areas.users.repositories;

import com.cyecize.mishmash.areas.users.entities.Role;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;

import java.util.List;

@Service
public class RoleRepository extends BaseRepository {

    public void createRole(Role role) {
        super.execute((actionResult) -> {
            super.entityManager.persist(role);
            super.entityManager.flush();
        });
    }

    public Role findOneById(Long id) {
        return (Role) super.execute((actionResult) -> {
            actionResult.setResult(super.entityManager.createQuery(
                    "SELECT r FROM Role r WHERE r.id = :roleId", Role.class
            ).setParameter("roleId", id));
        }).getResult();
    }

    public Role findOneByRoleType(String type) {
        return (Role) super.execute((actionResult) -> {
            actionResult.setResult(
                    super.entityManager.createQuery("SELECT r FROM Role r WHERE r.authority = :type", Role.class)
                            .setParameter("type", type)
                            .getSingleResult()
            );
        }).getResult();
    }

    @SuppressWarnings("unchecked")
    public List<Role> findAll() {
        return (List<Role>) super.execute(actionResult -> {
            actionResult.setResult(
                    this.entityManager.createQuery("SELECT r FROM Role r", Role.class).getResultList()
            );
        }).getResult();
    }
}
