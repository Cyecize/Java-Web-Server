package com.cyecize.mishmash.areas.users.services;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.users.bindingModels.UserRegisterBindingModel;
import com.cyecize.mishmash.areas.users.entities.User;

import java.util.List;

public interface UserService {

    void promote(User user);

    void createUser(UserRegisterBindingModel bindingModel);

    User findOneById(Long id);

    User findOneByUsername(String username);

    User findOneByUsernameOrEmail(String handle);

    List<User> findByChannel(Channel channel);

    List<User> findAll();
}
