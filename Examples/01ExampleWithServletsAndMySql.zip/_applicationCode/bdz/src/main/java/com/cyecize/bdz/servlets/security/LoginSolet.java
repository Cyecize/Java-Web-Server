package com.cyecize.bdz.servlets.security;

import com.cyecize.bdz.constants.WebConstants;
import com.cyecize.http.HttpStatus;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;

@WebSolet("/login")
public class LoginSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        if (isSecured(request)) {
            redirectToHome(response);
            return;
        }
        response.setContent("g".getBytes());
        response.setStatusCode(HttpStatus.SEE_OTHER);
        response.addHeader("Location", "/login.html");
    }

    @Override
    protected void doPost(HttpSoletRequest request, HttpSoletResponse response) {
        if (isSecured(request)) {
            redirectToHome(response);
            return;
        }
        String username = request.getBodyParameters().get("username");
        String password = request.getBodyParameters().get("password");

        request.getSession().getAttributes().put(WebConstants.USERNAME_SESSION_ID, username);
        request.getSession().getAttributes().put("password", password);

        redirectToHome(response);
    }

    private boolean isSecured(HttpSoletRequest request) {
        return request.getSession().getAttributes().containsKey(WebConstants.USERNAME_SESSION_ID);
    }

    private void redirectToHome(HttpSoletResponse response) {
        response.setContent("redirected".getBytes());
        response.setStatusCode(HttpStatus.SEE_OTHER);
        response.addHeader("Location", "/");
    }
}
