package com.cyecize.mishmash.areas.channels.bindingModels.dataAdapters;

import com.cyecize.mishmash.areas.channels.entities.ChannelCategory;
import com.cyecize.mishmash.areas.channels.services.CategoryService;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.summer.areas.validation.interfaces.DataAdapter;
import com.cyecize.summer.common.annotations.Component;

@Component
public class ChannelCategoryDataAdapter implements DataAdapter<ChannelCategory> {

    private final CategoryService categoryService;

    public ChannelCategoryDataAdapter(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @Override
    public ChannelCategory resolve(String catName, HttpSoletRequest httpSoletRequest) {
        if (catName == null) return null;

        return this.categoryService.findOneByName(catName);
    }
}
