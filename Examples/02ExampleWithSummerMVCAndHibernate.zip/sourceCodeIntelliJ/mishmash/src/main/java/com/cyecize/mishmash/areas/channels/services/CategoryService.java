package com.cyecize.mishmash.areas.channels.services;

import com.cyecize.mishmash.areas.channels.bindingModels.CategoryBindingModel;
import com.cyecize.mishmash.areas.channels.entities.ChannelCategory;

import java.util.List;

public interface CategoryService {

    void createCategory(CategoryBindingModel bindingModel);

    ChannelCategory findOneByName(String name);

    List<ChannelCategory> findAll();
}
