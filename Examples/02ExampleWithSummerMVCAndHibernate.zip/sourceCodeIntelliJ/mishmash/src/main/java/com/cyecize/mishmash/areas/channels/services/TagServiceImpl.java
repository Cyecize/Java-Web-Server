package com.cyecize.mishmash.areas.channels.services;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.channels.entities.Tag;
import com.cyecize.mishmash.areas.channels.repositories.TagRepository;
import com.cyecize.summer.common.annotations.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TagServiceImpl implements TagService {

    private final TagRepository tagRepository;

    public TagServiceImpl(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    @Override
    public Tag findOneById(Long id) {
        return this.tagRepository.find(id);
    }

    @Override
    public Tag findOneByName(String name) {
        return this.tagRepository.findOneByName(name);
    }

    @Override
    public List<Tag> findOrCreateTags(List<String> tagNames) {
        List<Tag> tags = new ArrayList<>();

        for (String tagName : tagNames) {
            Tag tag = this.findOneByName(tagName);

            if (tag == null)
                tag = this.createAndGet(tagName);

            tags.add(tag);
        }

        return tags;
    }

    @Override
    public List<Tag> findByChannels(List<Channel> channels) {
        List<Tag> tags = new ArrayList<>();
        for (Channel channel : channels) {
            for (Tag tag : channel.getTags()) {
                this.addTagIfNotExist(tags, tag);
            }
        }
        return tags;
    }

    @Override
    public List<Tag> findAll() {
        return this.tagRepository.findAll();
    }

    private Tag createAndGet(String name) {
        Tag tag = new Tag();
        tag.setTagName(name);
        this.tagRepository.persist(tag);
        return this.findOneByName(name);
    }

    private void addTagIfNotExist(List<Tag> tags, Tag tag) {
        for (Tag tag1 : tags) {
            if (tag1.getId().equals(tag.getId()))
                return;
        }
        tags.add(tag);
    }
}
