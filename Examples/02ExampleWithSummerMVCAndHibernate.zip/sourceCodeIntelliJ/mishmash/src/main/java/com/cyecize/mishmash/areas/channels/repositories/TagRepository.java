package com.cyecize.mishmash.areas.channels.repositories;

import com.cyecize.mishmash.areas.channels.entities.Tag;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;


@Service
public class TagRepository extends BaseRepository<Tag, Long> {

    public Tag findOneByName(String name) {
       return super.queryBuilderSingle((tagCriteriaQuery, tagRoot) -> tagCriteriaQuery.where(
               super.criteriaBuilder.equal(tagRoot.get("tagName"), name)
       ));
    }
}
