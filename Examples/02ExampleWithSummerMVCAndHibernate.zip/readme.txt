This application is utilizing Summer MVC Framework with fully set up environment:
Javache (Broccolina, Toyote)
Libraries and put in lib folder.
Application is loaded in webapps folder with default db password of toor.

It also uses hibernate and ModelMapper.
the default password for the db is toor and the address is localhost:3306 user - root

This application is a part of an exam in a software university but I used it here to demonstrate the functionalities
of the summer framework.

a .docx file with a short app description will be present. NOTE that the application's functionalities are 
extended from the description. For example the final app has 2 languages to show how interceptors work.

It also packs:
Custom Data Binders
Custom Validators
Custom Services/TempalteServices and more.

In the source code you can see that I am also using javache embedded while working on the application, but javache embedded
is not required once we put the app on the standalone server.

You can open the project in intellij and see how the artifact is created.

Also you can read the documentation and see how to build the app for the standalone server.

