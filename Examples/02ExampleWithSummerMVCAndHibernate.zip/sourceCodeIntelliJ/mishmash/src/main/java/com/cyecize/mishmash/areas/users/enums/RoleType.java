package com.cyecize.mishmash.areas.users.enums;

public enum RoleType {
    ROLE_ADMIN, ROLE_USER
}
