NOTE!!!!
	Some of the libraries in this example might have newer versions.

This application "bdz" is created to show the functionalities of javache web server
together with broccolina and coyote, the http and solet APIs and the ability to dynamically load libraries.

To run the server on Windows, click on the .bat file and make sure port 8000 is free.
Once it loads you will find a simple page with a navbar and a couple of links.

The goal is to demonstrate the functionality of the following things:
cookies (the session ID is kept in a cookie)
sessions - session storage unique for every visitor.
resource handling - loading images, css and js files.
request handling - body, query params, methods, routes, redirects, Http status codes.
third party libraries - in this case Gson and MySql driver.

Libraties can be placed in the lib folder in javache or in the lib folder in the specific app.
javache's lib folder is global and the jar files there are available to every app.


Inside the app you can find an option to test mysql with your own connection string.

how do you create your own app based on httpsolets?
first create a maven project and import http and solet apis (check out my pom.xml).

then create a class that extends BaseHttpSolet and has attribute @WebSolet("/route")

To deploy the app you need to create a custom artifact.
	.jar file with 3 folders
	classes - put the compile output there
	resources - put a copy of your resources module
	lib - put the depending .jar files there (http and solet are not required)
	
You can open the project with Intellij Idea and see exactly how the ROOT.jar is created.