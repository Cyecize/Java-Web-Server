package com.cyecize.mishmash.config;

import com.cyecize.mishmash.utils.ModelMerger;
import com.cyecize.summer.areas.security.models.SecurityConfig;
import com.cyecize.summer.common.annotations.Bean;
import com.cyecize.summer.common.annotations.BeanConfig;
import org.modelmapper.ModelMapper;

@BeanConfig
public class BeanCfg {

    public BeanCfg() {

    }

    @Bean
    public SecurityConfig getSecurityConfig() {
        return new SecurityConfig()
                .setLoginURL("/login")
                .setLogoutURL("/logout")
                .setLogoutRedirectURL("/")
                .setUnauthorizedURL("/unauthorized");
    }

    @Bean
    public ModelMapper getModelMapper() {
        return new ModelMapper();
    }

    @Bean
    public ModelMerger getModelMerger() {
        return new ModelMerger();
    }
}
