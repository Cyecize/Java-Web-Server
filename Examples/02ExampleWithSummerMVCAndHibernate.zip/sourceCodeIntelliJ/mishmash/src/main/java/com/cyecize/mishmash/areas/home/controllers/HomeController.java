package com.cyecize.mishmash.areas.home.controllers;

import com.cyecize.mishmash.areas.channels.entities.Tag;
import com.cyecize.mishmash.areas.channels.services.ChannelService;
import com.cyecize.mishmash.areas.channels.services.TagService;
import com.cyecize.mishmash.areas.home.viewModels.HomeViewModel;
import com.cyecize.mishmash.areas.language.services.LocalLanguage;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.mishmash.areas.users.services.UserService;
import com.cyecize.mishmash.controllers.BaseController;
import com.cyecize.summer.areas.security.models.Principal;
import com.cyecize.summer.common.annotations.Controller;
import com.cyecize.summer.common.annotations.routing.GetMapping;
import com.cyecize.summer.common.models.ModelAndView;

import java.util.List;

@Controller
public class HomeController extends BaseController {

    private final ChannelService channelService;

    private final UserService userService;

    private final TagService tagService;

    public HomeController(LocalLanguage localLanguage, ChannelService channelService, UserService userService, TagService tagService) {
        super(localLanguage);
        this.channelService = channelService;
        this.userService = userService;
        this.tagService = tagService;
    }

    @GetMapping("/")
    public ModelAndView indexAction(Principal principal) {
        if (!principal.isUserPresent())
            return view("default/index.twig");

        return loggedUser(principal);
    }

    private ModelAndView loggedUser(Principal principal) {
        User loggedInUser = this.userService.findOneByUsername(principal.getUser().getUsername());
        List<Tag> tags = this.tagService.findByChannels(loggedInUser.getSubscribedChannels());
        return view("default/index.twig", "viewModel", new HomeViewModel(
                loggedInUser.getSubscribedChannels(),
                this.channelService.findSuggested(tags, loggedInUser),
                this.channelService.findOther(tags, loggedInUser)
        ));
    }
}
