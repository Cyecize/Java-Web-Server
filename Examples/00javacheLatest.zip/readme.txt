This build might be outdated at some point.
I will try my best to update this every time I upadte one of the apps, but
just to be sure, you can run mvn package on all requred apps and replace the existing jar files.

Everything is pre-defined. You just need to put your app.jar and run the server.