package com.cyecize.mishmash.areas.channels.services;

import com.cyecize.mishmash.areas.channels.bindingModels.CategoryBindingModel;
import com.cyecize.mishmash.areas.channels.entities.ChannelCategory;
import com.cyecize.mishmash.areas.channels.repositories.CategoryRepository;
import com.cyecize.summer.common.annotations.Service;
import org.modelmapper.ModelMapper;

import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;

    private final ModelMapper modelMapper;

    public CategoryServiceImpl(CategoryRepository categoryRepository, ModelMapper modelMapper) {
        this.categoryRepository = categoryRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public void createCategory(CategoryBindingModel bindingModel) {
        ChannelCategory channelCategory = this.modelMapper.map(bindingModel, ChannelCategory.class);
        this.categoryRepository.persist(channelCategory);
    }

    @Override
    public ChannelCategory findOneByName(String name) {
        return this.categoryRepository.findOneByName(name);
    }

    @Override
    public List<ChannelCategory> findAll() {
        return this.categoryRepository.findAll();
    }
}
