package com.cyecize.mishmash.controllers;

import com.cyecize.mishmash.areas.language.services.LocalLanguage;
import com.cyecize.summer.areas.routing.exceptions.HttpNotFoundException;
import com.cyecize.summer.areas.security.exceptions.UnauthorizedException;
import com.cyecize.summer.common.annotations.Controller;
import com.cyecize.summer.common.annotations.routing.ExceptionListener;
import com.cyecize.summer.common.models.ModelAndView;

@Controller
public class ExceptionListeners extends BaseController {

    public ExceptionListeners(LocalLanguage localLanguage) {
        super(localLanguage);
    }

    @ExceptionListener(HttpNotFoundException.class)
    public ModelAndView notFoundAction(HttpNotFoundException ex) {
        return view("/errors/404.twig", "ex", ex);
    }

    @ExceptionListener(UnauthorizedException.class)
    public ModelAndView unauthorizedAction(UnauthorizedException ex) {
        return view("/errors/401.twig", "ex", ex);
    }

}
