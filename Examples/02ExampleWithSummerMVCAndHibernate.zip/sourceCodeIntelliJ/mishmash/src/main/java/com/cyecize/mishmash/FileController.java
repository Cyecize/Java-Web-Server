package com.cyecize.mishmash;

import com.cyecize.summer.areas.routing.interfaces.UploadedFile;
import com.cyecize.summer.areas.validation.annotations.Valid;
import com.cyecize.summer.areas.validation.interfaces.BindingResult;
import com.cyecize.summer.areas.validation.models.FieldError;
import com.cyecize.summer.common.annotations.Controller;
import com.cyecize.summer.common.annotations.routing.PostMapping;

import java.io.IOException;

@Controller
public class FileController {

    @PostMapping("/files/upload")
    public String uploadFile(@Valid TestBindingModel bindingModel, BindingResult bindingResult) throws IOException {

        if (bindingResult.hasErrors()) {
            for (FieldError error : bindingResult.getErrors()) {
                System.out.println(error.getMessage());
                return "redirect:/";
            }
        }

        bindingModel.getUploadedFile().save("./", bindingModel.getUploadedFile().getUploadedFile().getFileName());

        return "redirect:/";
    }
}
