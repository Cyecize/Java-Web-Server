package com.cyecize.mishmash.areas.users.controllers;

import com.cyecize.http.HttpStatus;
import com.cyecize.mishmash.areas.language.services.LocalLanguage;
import com.cyecize.mishmash.areas.users.entities.User;
import com.cyecize.mishmash.areas.users.services.UserService;
import com.cyecize.mishmash.controllers.BaseController;
import com.cyecize.summer.areas.routing.exceptions.HttpNotFoundException;
import com.cyecize.summer.areas.security.annotations.PreAuthorize;
import com.cyecize.summer.common.annotations.Controller;
import com.cyecize.summer.common.annotations.routing.GetMapping;
import com.cyecize.summer.common.annotations.routing.PathVariable;
import com.cyecize.summer.common.annotations.routing.PostMapping;
import com.cyecize.summer.common.models.JsonResponse;
import com.cyecize.summer.common.models.ModelAndView;

import java.util.HashMap;

@Controller
@PreAuthorize(role = "ROLE_ADMIN")
public class AdminController extends BaseController {

    private final UserService userService;

    public AdminController(LocalLanguage localLanguage, UserService userService) {
        super(localLanguage);
        this.userService = userService;
    }

    @GetMapping("/admin/users/observe")
    public ModelAndView allUsers() {
        return super.view("admin/users/observe-users.twig", "users", this.userService.findAll());
    }

    @PostMapping(value = "/admin/users/{id}/promote", produces = "application/json")
    public JsonResponse promoteUser(@PathVariable("id") Long id) throws HttpNotFoundException {
        User user = this.userService.findOneById(id);
        if (user == null)
            throw new HttpNotFoundException("User with id " + id + " was not found!");
        this.userService.promote(user);

        return new JsonResponse(HttpStatus.OK, new HashMap<>() {{
            put("message", String.format("User %s was promoted", user.getUsername()));
        }});
    }

}
