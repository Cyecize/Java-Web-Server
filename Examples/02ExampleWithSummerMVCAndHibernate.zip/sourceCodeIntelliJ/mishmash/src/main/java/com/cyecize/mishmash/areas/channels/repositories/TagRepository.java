package com.cyecize.mishmash.areas.channels.repositories;

import com.cyecize.mishmash.areas.channels.entities.Tag;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;

import java.util.List;

@Service
public class TagRepository extends BaseRepository {

    public Tag findOneById(Long id) {
        return super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery("SELECT t FROM Tag t WHERE t.id =:tid", Tag.class)
                    .setParameter("tid", id)
                    .getSingleResult()
            );
        }).getResult();
    }

    public Tag findOneByName(String name) {
        return super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery("SELECT t FROM Tag t WHERE t.tagName = :tagName", Tag.class)
                    .setParameter("tagName", name)
                    .getResultStream().findFirst().orElse(null)
            );
        }).getResult();
    }

    public List<Tag> findAll() {
        return super.execute((ar) -> {
            ar.setResult(super.entityManager.createQuery("SELECT t FROM Tag t", Tag.class)
                    .getResultList()
            );
        }).getResult();
    }
}
