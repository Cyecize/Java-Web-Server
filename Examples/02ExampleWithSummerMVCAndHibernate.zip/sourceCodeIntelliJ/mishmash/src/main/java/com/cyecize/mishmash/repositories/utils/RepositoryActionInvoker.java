package com.cyecize.mishmash.repositories.utils;

public interface RepositoryActionInvoker {
    void invoke(RepositoryActionResult repositoryActionResult);
}
