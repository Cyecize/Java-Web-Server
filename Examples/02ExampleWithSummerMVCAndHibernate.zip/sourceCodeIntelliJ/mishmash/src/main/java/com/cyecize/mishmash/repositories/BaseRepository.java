package com.cyecize.mishmash.repositories;

import com.cyecize.summer.common.annotations.Autowired;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.lang.reflect.ParameterizedType;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

public abstract class BaseRepository<E, ID> {

    @Autowired
    protected EntityManager entityManager;

    protected final Class<E> persistentClass;

    protected final Class<ID> primaryKeyType;

    protected CriteriaBuilder criteriaBuilder;

    @SuppressWarnings("unchecked")
    public BaseRepository() {
        final ParameterizedType parameterizedType = this.getParameterizedType();
        this.persistentClass = (Class<E>) parameterizedType.getActualTypeArguments()[0];
        this.primaryKeyType = (Class<ID>) parameterizedType.getActualTypeArguments()[1];
    }

    public void persist(E entity) {
        this.executeNonResult(() -> this.entityManager.persist(entity));
    }

    public void merge(E entity) {
        this.executeNonResult(() -> this.entityManager.merge(entity));
    }

    public void remove(E entity) {
        this.executeNonResult((() -> this.entityManager.remove(entity)));
    }

    public Long count() {
        final String query = String.format("SELECT count (t) FROM %s t", this.persistentClass.getSimpleName());
        return this.execute(() -> this.entityManager.createQuery(query, Long.class).getSingleResult(), Long.class);
    }

    public E find(ID id) {
        return this.execute(() -> this.entityManager.find(this.persistentClass, id));
    }

    public List<E> findAll() {
        final String query = String.format("SELECT t FROM %s t", this.persistentClass.getSimpleName());
        return this.executeList(() -> entityManager.createQuery(query, this.persistentClass).getResultList());
    }

    @SuppressWarnings("unchecked")
    protected <T> T execute(Supplier<T> handler, Class<T> returnType) {
        return (T) this.runTransaction(handler);
    }

    protected E execute(Supplier<E> handler) {
        return this.execute(handler, this.persistentClass);
    }

    @SuppressWarnings("unchecked")
    protected <T> List<T> executeList(Supplier<List<T>> handler, Class<?> returnType) {
        return (List<T>) this.runTransaction(handler);
    }

    protected List<E> executeList(Supplier<List<E>> handler) {
        return this.executeList(handler, this.persistentClass);
    }

    protected void executeNonResult(Runnable handler) {
        this.runTransaction(() -> {
            handler.run();
            return null;
        });
    }

    @SuppressWarnings("unchecked")
    protected List<E> queryBuilderList(BiConsumer<CriteriaQuery<E>, Root<E>> invoker) {

        this.criteriaBuilder = this.entityManager.getCriteriaBuilder();

        return this.execute(() -> {
            CriteriaQuery<E> criteria = this.criteriaBuilder.createQuery(this.persistentClass);
            Root<E> root = criteria.from(this.persistentClass);
            criteria.select(root);

            invoker.accept(criteria, root);

            return this.entityManager.createQuery(criteria).getResultList();
        }, List.class);
    }

    protected E queryBuilderSingle(BiConsumer<CriteriaQuery<E>, Root<E>> invoker) {
        this.criteriaBuilder = this.entityManager.getCriteriaBuilder();

        return this.execute(() -> {
            CriteriaQuery<E> criteria = this.criteriaBuilder.createQuery(this.persistentClass);
            Root<E> root = criteria.from(this.persistentClass);
            criteria.select(root);

            invoker.accept(criteria, root);

            return this.entityManager.createQuery(criteria)
                    .getResultStream()
                    .findFirst().orElse(null);

        }, this.persistentClass);
    }

    private Object runTransaction(Supplier<?> handler) {
        Object invocationResult;
        try {
            this.entityManager.getTransaction().begin();

            invocationResult = handler.get();

            this.entityManager.getTransaction().commit();
        } catch (Exception ex) {
            this.entityManager.getTransaction().rollback();
            throw new RuntimeException(ex);
        }

        return invocationResult;
    }

    private ParameterizedType getParameterizedType() {
        if (this.getClass().getGenericSuperclass() instanceof ParameterizedType) {
            return (ParameterizedType) this.getClass().getGenericSuperclass();
        }

        return (ParameterizedType) this.getClass().getSuperclass().getGenericSuperclass();
    }
}