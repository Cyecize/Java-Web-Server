package com.cyecize.mishmash.areas.language;

public class Constants {
    public static final int COOKIE_MAX_AGE = 7200; //2hr

    public static final String COOKIE_LANG_NAME = "lang";
}
