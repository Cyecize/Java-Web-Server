package com.cyecize.mishmash.areas.channels.repositories;

import com.cyecize.mishmash.areas.channels.entities.ChannelCategory;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;

import java.util.List;

@Service
public class CategoryRepository extends BaseRepository {

    public ChannelCategory findOneByName(String name) {
        return (ChannelCategory) super.execute((repositoryActionResult -> {
            repositoryActionResult.setResult(
                    super.entityManager.createQuery("SELECT cc FROM ChannelCategory cc WHERE cc.cyrillicName =:catName OR cc.latinName =:catName", ChannelCategory.class)
                            .setParameter("catName", name)
                            .getResultStream().findFirst().orElse(null)

            );
        })).getResult();
    }

    @SuppressWarnings("unchecked")
    public List<ChannelCategory> findAll() {
        return (List<ChannelCategory>) super.execute((repositoryActionResult -> {
            repositoryActionResult.setResult(
                    super.entityManager.createQuery("SELECT cc FROM ChannelCategory cc", ChannelCategory.class)
                    .getResultList()
            );
        })).getResult();
    }
}
