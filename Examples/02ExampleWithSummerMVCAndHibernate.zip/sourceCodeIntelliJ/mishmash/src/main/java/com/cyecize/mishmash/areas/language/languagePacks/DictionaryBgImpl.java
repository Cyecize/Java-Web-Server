package com.cyecize.mishmash.areas.language.languagePacks;


import com.cyecize.mishmash.areas.language.enums.LanguageLocaleType;

public class DictionaryBgImpl implements Dictionary {

    public static final String HOME = "Начало";
    public static final String CONTACTS = "Контакти";
    public static final String ABOUT_US = "За нас";
    public static final String LOGIN = "Вход";
    public static final String REGISTER = "Регистрация";
    public static final String LOGOUT = "Изход";
    public static final String GO = "Напред";
    public static final String MENU = "Меню";
    public static final String USERNAME_IS_NULL = "Потребителското име е празно";
    public static final String USERNAME_INVALID_FORMAT = "Невалиден формат на потр.име";
    public static final String USERNAME_TAKEN = "Потр. име е заето";
    public static final String EMAIL_IS_NULL = "Email адресът е празен";
    public static final String EMAIL_IS_IN_USE = "Email адресът е зает";
    public static final String PASSWORDS_DO_NOT_MATCH = "Паролите не съвпадат";
    public static final String INCORRECT_PASSWORD = "Грешна парола";
    public static final String USERNAME = "Потр. име";
    public static final String EMAIL = "Email";
    public static final String PASSWORD = "Парола";
    public static final String PROFILE = "Моят профил";
    public static final String DETAILS = "Детайли";
    public static final String PAGE_IS_EMPTY = "Страницата е празна";
    public static final String FIELD_CANNOT_BE_EMPTY = "Полето не може да бъде празно";
    public static final String BACK = "Назад";
    public static final String INVALID_IMAGE = "Невалидна снимка / формат";
    public static final String LATIN_NAME = "Латинско име";
    public static final String CYRILLIC_NAME = "Име на кирилица";
    public static final String NAME_TAKEN = "Името е заето";
    public static final String REMOVE = "Изтриване";
    public static final String NAME = "Име";
    public static final String DESCRIPTION = "Описание";
    public static final String TITLE = "Заглавие";
    public static final String PAGE_NOT_FOUND = "Страницата не е намерена.";
    public static final String INVALID_VALUE = "Грешна стойност";
    public static final String INVALID_USERNAME_OR_EMAIL = "Грешно потр. име или Email";
    public static final String PAGE_IS_FORBIDDEN = "Страницата е забранена.";
    public static final String FOLLOWED = "Последвани";
    public static final String FOLLOWERS = "Последователи";
    public static final String CHANNEL = "Канал";
    public static final String CATEGORY = "Категория";
    public static final String ACTIONS = "Действия";
    public static final String CREATE_CHANNEL = "Нов канал";
    public static final String CATEGORIES = "Категории";
    public static final String CREATE_CATEGORY = "Нова категория";
    public static final String CATEGORY_NAME_TAKEN = "Името е заето";
    public static final String SHOW_ALL = "Покажи всички";
    public static final String CHANNELS = "Канали";
    public static final String TAGS = "Тагове";
    public static final String ADD_TAG = "Нов Таг";
    public static final String WELCOME  = "Здравей";
    public static final String OTHER  = "Други";
    public static final String SUGGESTED  = "Предложени";
    public static final String FOLLOWING  = "Последователи";
    public static final String FOLLOW  = "Последване";


    public String follow() {
        return FOLLOW;
    }

    public String following() {
        return FOLLOWING;
    }

    public String suggested() {
        return SUGGESTED;
    }

    public String other() {
        return OTHER;
    }

    public String welcome() {
        return WELCOME;
    }

    public String channels() {
        return CHANNELS;
    }

    public String tags() {
        return TAGS;
    }

    public String addTag() {
        return ADD_TAG;
    }

    public String showAll() {
        return SHOW_ALL;
    }

    public String categoryNameTaken() {
        return CATEGORY_NAME_TAKEN;
    }

    public String categories() {
        return CATEGORIES;
    }

    public String createCategory() {
        return CREATE_CATEGORY;
    }

    public String createChannel() {
        return CREATE_CHANNEL;
    }

    public String followers() {
        return FOLLOWERS;
    }

    public String channel() {
        return CHANNEL;
    }

    public String category() {
        return CATEGORY;
    }

    public String actions() {
        return ACTIONS;
    }

    public String followed() {
        return FOLLOWED;
    }

    public String pageIsForbidden() {
        return PAGE_IS_FORBIDDEN;
    }

    public String invalidUsernameOrEmail() {
        return INVALID_USERNAME_OR_EMAIL;
    }

    public String invalidValue() {
        return INVALID_VALUE;
    }

    public String pageNotFound() {
        return PAGE_NOT_FOUND;
    }

    public String title() {
        return TITLE;
    }

    public String name() {
        return NAME;
    }

    public String description() {
        return DESCRIPTION;
    }

    public String remove() {
        return REMOVE;
    }

    public String nameTaken() {
        return NAME_TAKEN;
    }

    public String latinName() {
        return LATIN_NAME;
    }

    public String cyrillicName() {
        return CYRILLIC_NAME;
    }

    public String invalidImage() {
        return INVALID_IMAGE;
    }

    public String back() {
        return BACK;
    }

    public String fieldCannotBeEmpty() {
        return FIELD_CANNOT_BE_EMPTY;
    }

    public String pageIsEmpty() {
        return PAGE_IS_EMPTY;
    }

    public String details() {
        return DETAILS;
    }

    public String profile() {
        return PROFILE;
    }

    public String username() {
        return USERNAME;
    }

    public String email() {
        return EMAIL;
    }

    public String password() {
        return PASSWORD;
    }

    public String usernameIsNull() {
        return USERNAME_IS_NULL;
    }

    public String usernameInvalidFormat() {
        return USERNAME_INVALID_FORMAT;
    }

    public String usernameTaken() {
        return USERNAME_TAKEN;
    }

    public String emailIsNull() {
        return EMAIL_IS_NULL;
    }

    public String emailTaken() {
        return EMAIL_IS_IN_USE;
    }

    public String passwordLengthIsLessThan() {
        return "Паролата е под " + 6 + " знака";
    }

    public String passwordsDoNotMatch() {
        return PASSWORDS_DO_NOT_MATCH;
    }

    public String passwordIsIncorrect() {
        return INCORRECT_PASSWORD;
    }

    public LanguageLocaleType getLocaleType() {
        return LanguageLocaleType.BG;
    }

    public String home() {
        return HOME;
    }

    public String contacts() {
        return CONTACTS;
    }

    public String aboutUs() {
        return ABOUT_US;
    }

    public String login() {
        return LOGIN;
    }

    public String register() {
        return REGISTER;
    }

    public String logout() {
        return LOGOUT;
    }

    public String go() {
        return GO;
    }

    public String menu() {
        return MENU;
    }
}


