package com.cyecize.mishmash.areas.channels.services;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.mishmash.areas.channels.entities.Tag;

import java.util.List;

public interface TagService {

    Tag findOneById(Long id);

    Tag findOneByName(String name);

    List<Tag> findOrCreateTags(List<String> tagNames);

    List<Tag> findByChannels(List<Channel> channels);

    List<Tag> findAll();

}
