package com.cyecize.mishmash.repositories.utils;

public interface RepositoryActionResult {

    <T> T getResult();

    <T> void setResult(T result);
}
