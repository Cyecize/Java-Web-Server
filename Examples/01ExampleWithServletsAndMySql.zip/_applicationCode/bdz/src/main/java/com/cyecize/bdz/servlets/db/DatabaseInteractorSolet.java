package com.cyecize.bdz.servlets.db;

import com.cyecize.bdz.constants.WebConstants;
import com.cyecize.http.HttpRequest;
import com.cyecize.http.HttpResponse;
import com.cyecize.http.HttpStatus;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;
import com.google.gson.Gson;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@WebSolet("/database/interact")
public class DatabaseInteractorSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        if (this.notLoggedOrDbInvalid(request)) {
            this.redirectHome(response);
            return;
        }

        try {
            Connection connection = (Connection) request.getSession().getAttributes().get(WebConstants.DB_CONNECTION_SESSION_ID);
            response.setStatusCode(HttpStatus.OK);
            response.addHeader("Content-Type", "application/json");

            List<String> entries = new ArrayList<>();
            ResultSet resultSet = connection.prepareStatement("SELECT * FROM entries").executeQuery();
            while (resultSet.next())
                entries.add(resultSet.getString("entry_name"));

            response.setContent(new Gson().toJson(entries).getBytes());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
            redirectHome(response);
        }
    }

    @Override
    protected void doPost(HttpSoletRequest request, HttpSoletResponse response) {
        if (this.notLoggedOrDbInvalid(request)) {
            this.redirectHome(response);
            return;
        }
        try {
        Connection connection = (Connection) request.getSession().getAttributes().get(WebConstants.DB_CONNECTION_SESSION_ID);
        String entryName = request.getBodyParameters().get("entryName");
        connection.prepareStatement(String.format("INSERT INTO entries VALUES (null, '%s')", entryName)).execute();

        response.addHeader("Content-Type", "application/json");
        response.setContent("true".getBytes());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
            redirectHome(response);
        }
    }

    private boolean notLoggedOrDbInvalid(HttpRequest request) {
        var session = request.getSession().getAttributes();
        return !session.containsKey(WebConstants.USERNAME_SESSION_ID) || !session.containsKey(WebConstants.DB_PROPERTIES_SESSION_ID) || session.get(WebConstants.DB_CONNECTION_SESSION_ID) == null;
    }

    private void redirectHome(HttpResponse response) {
        response.setContent(" ".getBytes());
        response.setStatusCode(HttpStatus.SEE_OTHER);
        response.addHeader("Location", "/");
    }
}
