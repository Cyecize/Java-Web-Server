package com.cyecize.bdz.servlets;

import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;

import java.nio.charset.StandardCharsets;

@WebSolet("/")
public class HomeSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        response.sendRedirect(super.createRoute("/index.html"));
    }
}
