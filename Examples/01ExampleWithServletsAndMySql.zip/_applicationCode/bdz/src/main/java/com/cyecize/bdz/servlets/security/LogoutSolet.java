package com.cyecize.bdz.servlets.security;

import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;

@WebSolet("/logout")
public class LogoutSolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        request.getSession().invalidate();
        response.sendRedirect(super.createRoute("/"));
    }
}