package com.cyecize.mishmash.areas.users.repositories;

import com.cyecize.mishmash.areas.users.entities.Role;
import com.cyecize.mishmash.repositories.BaseRepository;
import com.cyecize.summer.common.annotations.Service;

import java.util.List;

@Service
public class RoleRepository extends BaseRepository<Role, Long> {

    public Role findOneByRoleType(String type) {
        return super.queryBuilderSingle((roleCriteriaQuery, roleRoot) -> roleCriteriaQuery.where(
                super.criteriaBuilder.equal(roleRoot.get("authority"), type)
        ));
    }
}
