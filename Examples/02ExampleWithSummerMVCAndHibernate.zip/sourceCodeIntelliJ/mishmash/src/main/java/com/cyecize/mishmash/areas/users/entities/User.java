package com.cyecize.mishmash.areas.users.entities;

import com.cyecize.mishmash.areas.channels.entities.Channel;
import com.cyecize.summer.areas.security.interfaces.GrantedAuthority;
import com.cyecize.summer.areas.security.interfaces.UserDetails;

import javax.persistence.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Table(name = "users")
public class User implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, unique = true, updatable = false)
    private Long id;

    @Column(name = "username", unique = true, nullable = false)
    private String username;

    @Column(name = "email", unique = true, updatable = false)
    private String email;

    @Column(name = "password", nullable = false)
    private String password;

    @ManyToMany(targetEntity = Role.class, cascade = CascadeType.REMOVE)
    @JoinTable(name = "users_roles",
            joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"))
    private List<GrantedAuthority> roles;

    @ManyToMany(targetEntity = Channel.class)
    @JoinTable(name = "users_channels",
            joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "channel_id", referencedColumnName = "id"))
    private List<Channel> subscribedChannels;

    public User() {
        this.subscribedChannels = new ArrayList<>();
        this.roles = new ArrayList<>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Transient
    public Collection<GrantedAuthority> getAuthorities() {
        return this.roles;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<GrantedAuthority> getRoles() {
        return roles;
    }

    public void setRoles(List<GrantedAuthority> roles) {
        this.roles = roles;
    }

    public List<Channel> getSubscribedChannels() {
        return subscribedChannels;
    }

    public void setSubscribedChannels(List<Channel> subscribedChannels) {
        this.subscribedChannels = subscribedChannels;
    }

    @Transactional
    public void addRole(Role role) {
        if (this.roles.stream().anyMatch(r -> r.getAuthority().equalsIgnoreCase(role.getAuthority())))
            return;
        this.roles.add(role);
    }

    @Transactional
    public void removeRole(Role role) {
        if (!this.roles.contains(role))
            return;
        this.roles.remove(role);
    }

    @Transactional
    public void addChannel(Channel channel) {
        if (this.subscribedChannels.contains(channel))
            return;
        this.subscribedChannels.add(channel);
        channel.getSubscribers().add(this);
    }

    @Transactional
    public void removeChannel(Channel channel) {
        this.subscribedChannels = this.subscribedChannels.stream()
                .filter(sc -> !sc.getId().equals(channel.getId()))
                .collect(Collectors.toList());

        channel.setSubscribers(
                channel.getSubscribers().stream()
                        .filter(cs -> !cs.getId().equals(this.getId()))
                        .collect(Collectors.toList())
        );
    }
}
