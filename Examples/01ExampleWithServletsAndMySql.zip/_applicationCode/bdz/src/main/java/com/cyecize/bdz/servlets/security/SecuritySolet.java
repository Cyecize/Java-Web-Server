package com.cyecize.bdz.servlets.security;

import com.cyecize.bdz.constants.WebConstants;
import com.cyecize.solet.BaseHttpSolet;
import com.cyecize.solet.HttpSoletRequest;
import com.cyecize.solet.HttpSoletResponse;
import com.cyecize.solet.WebSolet;

@WebSolet("/secured")
public class SecuritySolet extends BaseHttpSolet {

    @Override
    protected void doGet(HttpSoletRequest request, HttpSoletResponse response) {
        response.addHeader("Content-Type", "application/json");
        response.setContent((request.getSession().getAttributes().containsKey(WebConstants.USERNAME_SESSION_ID) + "").getBytes());
    }
}
