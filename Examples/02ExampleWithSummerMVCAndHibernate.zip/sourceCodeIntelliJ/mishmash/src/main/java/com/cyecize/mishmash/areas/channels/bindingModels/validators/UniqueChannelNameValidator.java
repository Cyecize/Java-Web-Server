package com.cyecize.mishmash.areas.channels.bindingModels.validators;

import com.cyecize.mishmash.areas.channels.services.ChannelService;
import com.cyecize.summer.areas.validation.interfaces.ConstraintValidator;
import com.cyecize.summer.common.annotations.Component;

@Component
public class UniqueChannelNameValidator implements ConstraintValidator<UniqueChannelName, String> {

    private final ChannelService channelService;

    public UniqueChannelNameValidator(ChannelService channelService) {
        this.channelService = channelService;
    }

    @Override
    public boolean isValid(String s, Object o) {
        if (s == null)
            s = "";
        return this.channelService.findOneByName(s) == null;
    }
}
