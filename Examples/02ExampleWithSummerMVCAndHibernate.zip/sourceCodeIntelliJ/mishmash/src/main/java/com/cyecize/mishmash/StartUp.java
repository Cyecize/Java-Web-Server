package com.cyecize.mishmash;

import com.cyecize.summer.DispatcherSolet;
import com.cyecize.summer.SummerBootApplication;

public class StartUp extends DispatcherSolet {
    public StartUp() {
        SummerBootApplication.run(this);
    }
}
