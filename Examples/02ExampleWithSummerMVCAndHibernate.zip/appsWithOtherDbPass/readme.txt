localhost:3306
root
pass - depends

Just rename the .jar to ROOT and paste in webapps.
or leave it like that, but you will have to access it like localhost:8000/nameOfJar/