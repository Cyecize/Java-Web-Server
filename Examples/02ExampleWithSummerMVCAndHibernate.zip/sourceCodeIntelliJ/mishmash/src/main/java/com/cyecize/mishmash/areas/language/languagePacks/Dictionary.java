package com.cyecize.mishmash.areas.language.languagePacks;

import com.cyecize.mishmash.areas.language.enums.LanguageLocaleType;

public interface Dictionary extends ErrorDictionary {

    LanguageLocaleType getLocaleType();

    String home();

    String contacts();

    String aboutUs();

    String login();

    String register();

    String logout();

    String go();

    String menu();

    String username();

    String email();

    String password();

    String profile();

    String details();

    String back();

    String remove();

    String name();

    String description();

    String title();

    String followed();

    String followers();

    String channel();

    String category();

    String actions();

    String createChannel();

    String categories();

    String createCategory();

    String latinName();

    String cyrillicName();

    String showAll();

    String channels();

    String tags();

    String addTag();

    String welcome();

    String suggested();

    String other();

    String following();

    String follow();

    String testConfigs();
}
