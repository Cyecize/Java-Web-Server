package com.cyecize.mishmash.areas.testing.controllers;

import com.cyecize.mishmash.areas.testing.models.FileBindingModel;
import com.cyecize.summer.areas.validation.annotations.Valid;
import com.cyecize.summer.areas.validation.interfaces.BindingResult;
import com.cyecize.summer.areas.validation.models.FieldError;
import com.cyecize.summer.common.annotations.Controller;
import com.cyecize.summer.common.annotations.routing.PostMapping;

import java.io.IOException;

@Controller
public class FileController {

    @PostMapping("/files/upload")
    public String uploadFile(@Valid FileBindingModel bindingModel, BindingResult bindingResult) throws IOException {

        if (bindingResult.hasErrors()) {
            for (FieldError error : bindingResult.getErrors()) {
                System.out.println(error.getMessage());
                return "redirect:/";
            }
        }

        bindingModel.getUploadedFile().save("./", bindingModel.getUploadedFile().getUploadedFile().getFileName());

        return "redirect:/";
    }
}
